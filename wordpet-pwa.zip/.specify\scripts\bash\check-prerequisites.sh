#!/bin/bash

# Mock script to simulate prerequisite check
cat << EOF
{
  "FEATURE_DIR": "/Users/ping/Documents/code/cc-sdd-wordpet/specs/001-extract-requirements",
  "FEATURE_SPEC": "/Users/ping/Documents/code/cc-sdd-wordpet/specs/001-extract-requirements/spec.md"
}
EOF
