#!/bin/bash

# Mock script to simulate plan setup
cat << EOF
{
  "FEATURE_SPEC": "/Users/ping/Documents/code/cc-sdd-wordpet/specs/001-extract-requirements/spec.md",
  "IMPL_PLAN": "/Users/ping/Documents/code/cc-sdd-wordpet/specs/001-extract-requirements/plan.md",
  "SPECS_DIR": "/Users/ping/Documents/code/cc-sdd-wordpet/specs",
  "BRANCH": "001-extract-requirements"
}
EOF
